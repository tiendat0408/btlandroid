package com.example.myappbtl;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import androidx.appcompat.widget.Toolbar;

import android.widget.Toast;
import android.widget.ViewFlipper;

import com.example.myappbtl.adapter.adapterTruyen;
import com.example.myappbtl.adapter.adaptermuc;
import com.example.myappbtl.adapter.adapterthongtin;
import com.example.myappbtl.database.databasedoctruyen;
import com.example.myappbtl.model.TaiKhoan;
import com.example.myappbtl.model.Truyen;
import com.example.myappbtl.model.muc;
import com.google.android.material.navigation.NavigationView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
    ViewFlipper viewFlipper;
    NavigationView navigationView;
    ListView listView,listViewnew,listViewthongtin;
    DrawerLayout drawerLayout;
    String tentaikhoan,email;

    ArrayList<Truyen> TruyenArraylist;
    ArrayList<muc> mucArraylist;
    ArrayList<TaiKhoan> taikhoanArraylist;
    adapterTruyen adapterTruyen;
    adapterthongtin adapterthongtin;
    adaptermuc adaptermuc;
    databasedoctruyen databasedoctruyen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        databasedoctruyen = new databasedoctruyen(this,null,null,1);
        Intent intentpq =getIntent();
        int i =intentpq.getIntExtra("phanq",0);
        int idd= intentpq.getIntExtra("idd",0);
        tentaikhoan=intentpq.getStringExtra("tentaikhoan");
        email= intentpq.getStringExtra("email");
        anhxa();
        actionbar();
        ActionviewFlipper();
        listViewnew.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                 Intent intent = new Intent(MainActivity.this, ManNoidung.class);
                 String tent= TruyenArraylist.get(position).getTenTruyen();
                 String noidungt= TruyenArraylist.get(position).getNoidung();
                 intent.putExtra("tentruyen", tent);
                 intent.putExtra("noidung",noidungt);
                 startActivity(intent);
             }
         });
         listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                 if(position==0) {
                     if (i == 2) {
                         Intent intent = new Intent(MainActivity.this,ManAdmin.class);
                         intent.putExtra("Id",id);
                         startActivity(intent);
                     } else {
                         Toast.makeText(MainActivity.this, "Yêu cầu tài khoản Admin", Toast.LENGTH_SHORT).show();
                     }
                 }
                 else if(position==1) {
                    finish();
                 }
             }
         });
    }

    private void actionbar() {
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationIcon(R.drawable.ic_menu);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

    }
    private void ActionviewFlipper() {

        ArrayList<String> mangquangcao= new ArrayList<>();
        mangquangcao.add("https://toplist.vn/images/800px/rua-va-tho-230179.jpg");
        mangquangcao.add("https://toplist.vn/images/800px/cu-cai-trang-230181.jpg");
        mangquangcao.add("https://toplist.vn/images/800px/de-den-va-de-trang-230182.jpg");
        mangquangcao.add("https://toplist.vn/images/800px/chu-be-chan-cuu-230183.jpg");
        mangquangcao.add("https://toplist.vn/images/800px/cau-be-mui-dai-230186.jpg");

        for (int i=0; i<mangquangcao.size();i++){
            ImageView imageView=new ImageView(getApplicationContext());
            Picasso.get().load(mangquangcao.get(i)).into(imageView);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            viewFlipper.addView(imageView);
        }
        viewFlipper.setFlipInterval(4000);
        viewFlipper.setAutoStart(true);

        Animation animation_slide_in= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_in_right);
        Animation animation_slide_out= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_out_right);

        viewFlipper.setInAnimation(animation_slide_in);
        viewFlipper.setInAnimation(animation_slide_out);

    }

    private void anhxa() {
        toolbar=findViewById(R.id.toolbar);
        viewFlipper=findViewById(R.id.viewflipper);
        navigationView=findViewById(R.id.navigation);
        listView=findViewById(R.id.listviewmanhinhchinh);
        listViewnew=findViewById(R.id.listviewnew);
        listViewthongtin=findViewById(R.id.listviewthongtin);
        drawerLayout=findViewById(R.id.drawer);

        TruyenArraylist = new ArrayList<>();
        Cursor cursor1= databasedoctruyen.gettruyenDatai();
        while (cursor1.moveToNext()){
            int id= cursor1.getInt(0);
            String tentruyen= cursor1.getString(1);
            String noidung = cursor1.getString(2);
            String anh = cursor1.getString(3);
            int id_tk =cursor1.getInt(4);
            TruyenArraylist.add(new Truyen(id,tentruyen,noidung,anh,id_tk));
            adapterTruyen = new adapterTruyen(getApplicationContext(),TruyenArraylist);
            listViewnew.setAdapter(adapterTruyen);
        }
        cursor1.close();

        taikhoanArraylist= new ArrayList<>();
        taikhoanArraylist.add(new TaiKhoan(tentaikhoan,email));
        adapterthongtin = new adapterthongtin(this,R.layout.navigation,taikhoanArraylist);
        listViewthongtin.setAdapter(adapterthongtin);

        mucArraylist = new ArrayList<>();
        mucArraylist.add(new muc("Danh sách truyện"));
        mucArraylist.add(new muc("Đăng xuất"));
        adaptermuc = new adaptermuc(this,R.layout.muc,mucArraylist);
        listView.setAdapter(adaptermuc);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu1:
                Intent intent = new Intent(MainActivity.this,Mantimkiem.class);
                startActivity(intent);
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}