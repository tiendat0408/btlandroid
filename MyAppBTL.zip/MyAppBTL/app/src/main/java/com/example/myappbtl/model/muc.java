package com.example.myappbtl.model;

public class muc  {
    private String tenmuc;

    public muc(String tenmuc) {
        this.tenmuc = tenmuc;
    }

    public String getTenmuc() {
        return tenmuc;
    }

    public void setTenmuc(String tenmuc) {
        this.tenmuc = tenmuc;
    }
}
