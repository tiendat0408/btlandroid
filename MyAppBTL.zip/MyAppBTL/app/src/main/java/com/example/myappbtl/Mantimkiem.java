package com.example.myappbtl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import com.example.myappbtl.adapter.adapterTruyen;
import com.example.myappbtl.database.databasedoctruyen;
import com.example.myappbtl.model.Truyen;

import java.util.ArrayList;
import java.util.List;

public class Mantimkiem extends AppCompatActivity {
    ListView listView;
    EditText edtsearch;
    ArrayList<Truyen> TruyenArraylist;
    ArrayList<Truyen> arrayList;
    adapterTruyen adapterTruyen;
    databasedoctruyen databasedoctruyen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mantimkiem);
        listView = findViewById(R.id.listviewsearch);
        edtsearch = findViewById(R.id.timkiem);
        initlist();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(Mantimkiem.this,ManNoidung.class);
                String tent= arrayList.get(position).getTenTruyen();
                String noidungt= arrayList.get(position).getNoidung();
                intent.putExtra("tentruyen",tent);
                intent.putExtra("noidung",noidungt);
                startActivity(intent);
            }
        });
        edtsearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                filter(s.toString());
            }
        });

    }
        private void filter(String text){
            arrayList.clear();
            ArrayList<Truyen> filteredlist = new ArrayList<>();
            for(Truyen item : TruyenArraylist){
                if(item.getTenTruyen().toLowerCase().contains(text.toLowerCase())){
                    arrayList.add(item);
                    filteredlist.add(item);
                }
            }
            adapterTruyen.filterlist(filteredlist);
        }
    private void initlist() {
        TruyenArraylist = new ArrayList<>();
        arrayList = new ArrayList<>();
        databasedoctruyen = new databasedoctruyen(this,null,null,1);
        Cursor cursor =databasedoctruyen.getAlltruyen();
        while (cursor.moveToNext()){
            int id= cursor.getInt(0);
            String tentruyen = cursor.getString(1);
            String noidung = cursor.getString(2);
            int id_tk =  cursor.getInt(3);
            TruyenArraylist.add(new Truyen(id,tentruyen,noidung,id_tk));
            arrayList.add(new Truyen(id,tentruyen,noidung,id_tk));
            adapterTruyen = new adapterTruyen(getApplicationContext(),TruyenArraylist);
            listView.setAdapter(adapterTruyen);
        }
        cursor.close();

    }
}