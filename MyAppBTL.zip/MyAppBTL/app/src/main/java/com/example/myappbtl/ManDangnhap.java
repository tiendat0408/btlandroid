package com.example.myappbtl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myappbtl.database.databasedoctruyen;


public class ManDangnhap extends AppCompatActivity {
    EditText edtTaikhoan,edtMatkhau;
    Button btndangnhap,btndangky;

    databasedoctruyen databasedoctruyen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_man_dangnhap);
        anhxa();
        databasedoctruyen = new databasedoctruyen(this,null,null,1);
        btndangky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(ManDangnhap.this,ManDangky.class);
                startActivity(intent);
            }
        });
        btndangnhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tentaikhoan=edtTaikhoan.getText().toString();
                String matkhau=edtMatkhau.getText().toString();
                Cursor cursor=databasedoctruyen.getData();
                 while (cursor.moveToNext()){
                     String datatentk=cursor.getString(1);
                     String datamk=cursor.getString(2);
                     if (datatentk.equals(tentaikhoan) && datamk.equals(matkhau)){
                         int phanquyen=cursor.getInt(4);
                         int idd=cursor.getInt(0);
                         String email=cursor.getString(3);
                         String tentk=cursor.getString(1);
                         Intent intent=new Intent(ManDangnhap.this,MainActivity.class);
                         intent.putExtra("phanq",phanquyen);
                         intent.putExtra("idd",idd);
                         intent.putExtra("ten",tentk);
                         intent.putExtra("email",email);

                         startActivity(intent);
                     }

                 }
            }
        });
    }

    private void anhxa() {
        edtTaikhoan=findViewById(R.id.txtusername);
        edtMatkhau=findViewById(R.id.txtpassword);
        btndangnhap=findViewById(R.id.btndangnhap);
        btndangky=findViewById(R.id.btndangky);
    }
}