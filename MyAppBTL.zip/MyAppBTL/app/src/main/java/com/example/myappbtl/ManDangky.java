package com.example.myappbtl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myappbtl.database.databasedoctruyen;
import com.example.myappbtl.model.TaiKhoan;

public class ManDangky extends AppCompatActivity {
    EditText edtdktaikhoan,edtdkmatkhau,edtdkEmail;
    Button btndkdangky,btndkdangnhap;

    databasedoctruyen databasedoctruyen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_man_dangky);
        databasedoctruyen = new databasedoctruyen(this,null,null,1);
        anhxa();
        btndkdangky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String taikhoan=edtdktaikhoan.getText().toString();
                String matkhau= edtdkmatkhau.getText().toString();
                String email= edtdkEmail.getText().toString();
                TaiKhoan taiKhoann = creatTaikhoan();
                if(taikhoan.equals("") || matkhau.equals("") || email.equals("")){
                    Log.e("Thông báo","Bạn phải nhập đủ thông tin");
                }
                else {
                    databasedoctruyen.addTaikhoan(taiKhoann);
                    Toast.makeText(ManDangky.this,"Đăng ký thành công",Toast.LENGTH_LONG).show();
                }
            }
        });
        btndkdangnhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    private TaiKhoan creatTaikhoan(){
        String taikhoan=edtdktaikhoan.getText().toString();
        String matkhau= edtdkmatkhau.getText().toString();
        String email= edtdkEmail.getText().toString();
        int phanquyen=1;
        TaiKhoan tk=new TaiKhoan(taikhoan,matkhau,email,phanquyen);
        return  tk;
    }
    private void anhxa() {
        edtdktaikhoan=findViewById(R.id.txtdkusername);
        edtdkmatkhau=findViewById(R.id.txtdkpassword);
        edtdkEmail=findViewById(R.id.txtdkemail);
        btndkdangky=findViewById(R.id.btndkdangky);
        btndkdangnhap=findViewById(R.id.btndkdangnhap);
    }
}