package com.example.myappbtl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myappbtl.database.databasedoctruyen;
import com.example.myappbtl.model.Truyen;

public class ManThemTruyen extends AppCompatActivity {
    EditText edtTieude,edtNoidung,edtAnh;
    Button btnThemtr;
    databasedoctruyen databasedoctruyen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_man_them_truyen);
        edtTieude = findViewById(R.id.themtieude);
        edtNoidung = findViewById(R.id.themnoidung);
        edtAnh = findViewById(R.id.themimg);
        btnThemtr = findViewById(R.id.btnthemtr);

        databasedoctruyen = new databasedoctruyen(this,null,null,1);
        btnThemtr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tentruyen = edtTieude.getText().toString();
                String noidung = edtNoidung.getText().toString();
                String anh = edtAnh.getText().toString();
                Truyen truyen = Create();
                if(tentruyen.equals("") || noidung.equals("") || anh.equals("")){
                    Toast.makeText(ManThemTruyen.this,"Nhập đầy đủ thông tin",Toast.LENGTH_SHORT).show();
                }
                else {
                    databasedoctruyen.Themtruyen(truyen);
                    Intent intent= new Intent(ManThemTruyen.this,ManAdmin.class);
                    finish();
                    startActivity(intent);
                }
            }
        });
    }
    private Truyen Create(){
        String tentruyen =edtTieude.getText().toString();
        String noidung = edtNoidung.getText().toString();
        String anh = edtAnh.getText().toString();
        Intent intent = getIntent();
        int id = intent.getIntExtra("Id",0);
        Truyen truyen = new Truyen(tentruyen,noidung,anh,id);
        return truyen;

    }
}