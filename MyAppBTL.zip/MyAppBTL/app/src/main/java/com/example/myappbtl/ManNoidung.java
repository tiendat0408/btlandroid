package com.example.myappbtl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

public class ManNoidung extends AppCompatActivity {
    TextView txttentruyen,txtnoidung;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_man_noidung);
        txtnoidung=findViewById(R.id.noidung);
        txttentruyen=findViewById(R.id.TenTruyen);
        Intent intent = getIntent();
        String tentruyen= intent.getStringExtra("tentruyen");
        String noidung = intent.getStringExtra("noidung");

        txttentruyen.setText(tentruyen);
        txtnoidung.setText(noidung);
        txtnoidung.setMovementMethod(new ScrollingMovementMethod());
    }
}