package com.example.myappbtl;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myappbtl.adapter.adapterTruyen;
import com.example.myappbtl.database.databasedoctruyen;
import com.example.myappbtl.model.Truyen;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class ManAdmin extends AppCompatActivity {
    ListView listViewad;
    Button btnThem;

    ArrayList<Truyen> TruyenArrayList;
    adapterTruyen adaptertruyen;
    databasedoctruyen databasedoctruyen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_man_admin);

        listViewad = findViewById(R.id.listviewAD);
        btnThem = findViewById(R.id.buttonAddTruyen);

        initList();
        listViewad.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                DialogDelete(position);
                return false;
            }
        });
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = getIntent();
                int id = intent.getIntExtra("Id",0);
                Intent intent1 = new Intent(ManAdmin.this, ManThemTruyen.class);
                intent.putExtra("Id",id);
                startActivity(intent1);
            }
        });
    }
    private void DialogDelete(int position) {


        Dialog dialog  =  new Dialog(this);
        dialog.setContentView(R.layout.dialogdelete);
        dialog.setCanceledOnTouchOutside(false);
        Button btnYes = dialog.findViewById(R.id.btnYes);
        Button btnNo = dialog.findViewById(R.id.btnNo);

        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int idtruyen = TruyenArrayList.get(position).getID();
                databasedoctruyen.Delete(idtruyen);
                Intent intent = new Intent(ManAdmin.this,ManAdmin.class);
                finish();
                startActivity(intent);
                Toast.makeText(ManAdmin.this,"Xóa truyện thành công",Toast.LENGTH_SHORT).show();
            }
        });
        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });
        dialog.show();
    }
    public void initList(){
        TruyenArrayList = new ArrayList<>();
        databasedoctruyen = new databasedoctruyen(this,null,null,1);

        Cursor cursor1 = databasedoctruyen.getAlltruyen();

        while (cursor1.moveToNext()){

            int id = cursor1.getInt(0);
            String tentruyen = cursor1.getString(1);
            String noidung = cursor1.getString(2);
            String anh = cursor1.getString(3);
            int id_tk = cursor1.getInt(4);
            TruyenArrayList.add(new Truyen(id,tentruyen,noidung,anh,id_tk));
            adaptertruyen = new adapterTruyen(getApplicationContext(),TruyenArrayList);
            listViewad.setAdapter(adaptertruyen);
        }
        cursor1.close();
    }
}