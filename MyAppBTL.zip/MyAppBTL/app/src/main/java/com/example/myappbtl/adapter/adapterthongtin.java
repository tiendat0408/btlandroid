package com.example.myappbtl.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.myappbtl.R;
import com.example.myappbtl.model.TaiKhoan;

import java.util.List;

public class adapterthongtin extends BaseAdapter {
    private Context context;
    private int layout;
    private List<TaiKhoan> taikhoanlist;

    public adapterthongtin(Context context, int layout, List<TaiKhoan> taikhoanlist) {
        this.context = context;
        this.layout = layout;
        this.taikhoanlist = taikhoanlist;
    }

    @Override
    public int getCount() {
        return taikhoanlist.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView=inflater.inflate(layout,null);
        TextView txttentaikhoan =(TextView) convertView.findViewById(R.id.txtNAME);
        TextView txtGmail = (TextView) convertView.findViewById(R.id.txtGmail);
        TaiKhoan taiKhoan =taikhoanlist.get(position);
        txttentaikhoan.setText(taiKhoan.getmTentaikhoan());
        txtGmail.setText(taiKhoan.getmEmail());
        return convertView;
    }
}
